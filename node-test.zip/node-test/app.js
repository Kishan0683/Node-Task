const express = require('express');
const app = express();
const cors = require('cors');
app.use(express.json());
require('dotenv').config();

app.use(cors());
app.use(cors({
    origin : "https://localhost"
}))


const users = require('./route/user');
app.use('/users',users);

// app.get('/hello-word', function (req, res) {
//     res.send('Hello World')
//   })

try{
    server = app.listen(process.env.PORT);
    console.log('Connected to this port : '+ process.env.PORT)
} catch(error){
    console.log('Fail to connect the server');
}