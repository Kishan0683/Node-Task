const con = require('../config/database'); // MySQL connection

const users = {
  // Get all institute types
  getInstituteTypes: (req, res) => {
    con.query('SELECT * FROM tbl_institute_type', (err, result) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Error fetching institute types', error: err.message });
      }
      res.status(200).json({ success: true, data: result });
    });
  },

  // Get boards for schools
  getBoards: (req, res) => {
    con.query('SELECT * FROM tbl_boards', (err, result) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Error fetching boards', error: err.message });
      }
      res.status(200).json({ success: true, data: result });
    });
  },

  // Get mediums
  getMediums: (req, res) => {
    con.query('SELECT * FROM tbl_medium', (err, result) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Error fetching mediums', error: err.message });
      }
      res.status(200).json({ success: true, data: result });
    });
  },

  // Get class categories
  getClassCategories: (req, res) => {
    con.query('SELECT * FROM tbl_class_categories', (err, result) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Error fetching class categories', error: err.message });
      }
      res.status(200).json({ success: true, data: result });
    });
  },

  // Get standards by class category
  getStandards: (req, res) => {
    const { category_id } = req.body;
    con.query('SELECT * FROM tbl_standards WHERE category_id = ?', [category_id], (err, result) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Error fetching standards', error: err.message });
      }
      res.status(200).json({ success: true, data: result });
    });
  },

  // Get subjects by standard
  getSubjects: (req, res) => {
    const { standard_id } = req.body;
    con.query('SELECT * FROM tbl_subjects WHERE standard_id = ?', [standard_id], (err, result) => {
      if (err) {
        return res.status(500).json({ success: false, message: 'Error fetching subjects', error: err.message });
      }
      res.status(200).json({ success: true, data: result });
    });
  },

  // Register an institute
  registerInstitute: (req, res) => {
    const {
      institute_type_id,
      board_id,
      medium_id,
      class_category_id,
      standard_id,
      subject_ids,
      university_id,
      degree_type_id,
      exam_type_id,
    } = req.body;

    const query = `INSERT INTO tbl_register 
      (institute_type_id, board_id, medium_id, class_category_id, standard_id, subject_ids, university_id, degree_type_id, exam_type_id) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    con.query(
      query,
      [institute_type_id, board_id, medium_id, class_category_id, standard_id, subject_ids, university_id, degree_type_id, exam_type_id],
      (err, result) => {
        if (err) {
          return res.status(500).json({ success: false, message: 'Error registering institute', error: err.message });
        }
        res.status(200).json({ success: true, message: 'Institute registered successfully', data: { id: result.insertId } });
      }
    );
  },
};

module.exports = users;