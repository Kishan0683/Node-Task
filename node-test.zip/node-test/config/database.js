// Connection Database

var mysql = require('mysql');
require('dotenv').config();
var configurations = {
    host : process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
    dataString: 'data',
    connectionLimit: 10,
    timeout: 60000
}

// Connect the mysql database
var con = mysql.createPool(configurations);
module.exports = con;