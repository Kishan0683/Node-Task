-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2024 at 04:43 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `node_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_boards`
--

CREATE TABLE `tbl_boards` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_boards`
--

INSERT INTO `tbl_boards` (`id`, `name`, `is_active`, `is_delete`, `insert_date`, `update_date`) VALUES
(1, 'GSAB', 1, 0, '2024-11-26 14:58:05', '2024-11-26 14:58:05'),
(2, 'CBSE', 1, 0, '2024-11-26 14:58:05', '2024-11-26 14:58:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_class_categories`
--

CREATE TABLE `tbl_class_categories` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_class_categories`
--

INSERT INTO `tbl_class_categories` (`id`, `name`, `is_active`, `is_delete`, `insert_date`, `update_date`) VALUES
(1, 'Pre-primary', 1, 0, '2024-11-26 15:00:26', '2024-11-26 15:00:26'),
(2, 'Primary', 1, 0, '2024-11-26 15:00:26', '2024-11-26 15:00:26'),
(3, 'Secondary', 1, 0, '2024-11-26 15:00:48', '2024-11-26 15:00:48'),
(4, 'Higher Secondary', 1, 0, '2024-11-26 15:00:48', '2024-11-26 15:00:48');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_competitive_exam_type`
--

CREATE TABLE `tbl_competitive_exam_type` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_competitive_exam_type`
--

INSERT INTO `tbl_competitive_exam_type` (`id`, `name`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 'competitive_exam_1', 1, 0, '2024-11-26 15:04:06', '2024-11-26 15:04:06'),
(2, 'competitive_exam_2', 1, 0, '2024-11-26 15:04:06', '2024-11-26 15:04:06'),
(3, 'competitive_exam_3', 1, 0, '2024-11-26 15:04:16', '2024-11-26 15:04:16'),
(4, 'competitive_exam_4', 1, 0, '2024-11-26 15:04:16', '2024-11-26 15:04:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_degree_type`
--

CREATE TABLE `tbl_degree_type` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_degree_type`
--

INSERT INTO `tbl_degree_type` (`id`, `name`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 'Master Degree', 1, 0, '2024-11-26 15:05:09', '2024-11-26 15:05:09'),
(2, 'Bachelor Degree ', 1, 0, '2024-11-26 15:05:09', '2024-11-26 15:05:09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_institute_type`
--

CREATE TABLE `tbl_institute_type` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_institute_type`
--

INSERT INTO `tbl_institute_type` (`id`, `name`, `is_active`, `is_delete`, `insert_date`, `update_date`) VALUES
(1, 'Playhouses', 1, 0, '2024-11-26 15:05:56', '2024-11-26 15:11:39'),
(2, 'Colleges', 1, 0, '2024-11-26 15:05:56', '2024-11-26 15:11:55'),
(3, 'School', 1, 0, '2024-11-26 15:06:02', '2024-11-26 15:12:09'),
(4, 'Competitive Exam Center', 1, 0, '2024-11-26 15:12:27', '2024-11-26 15:12:27');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_medium`
--

CREATE TABLE `tbl_medium` (
  `id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_medium`
--

INSERT INTO `tbl_medium` (`id`, `name`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 'English', 1, 0, '2024-11-26 15:02:48', '2024-11-26 15:02:48'),
(2, 'Hindi', 1, 0, '2024-11-26 15:02:48', '2024-11-26 15:02:48'),
(3, 'Gujrati', 1, 0, '2024-11-26 15:03:00', '2024-11-26 15:03:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register`
--

CREATE TABLE `tbl_register` (
  `id` bigint(20) NOT NULL,
  `institute_type_id` bigint(20) DEFAULT NULL,
  `board_id` bigint(20) DEFAULT NULL,
  `medium_id` bigint(20) DEFAULT NULL,
  `class_category_id` bigint(20) DEFAULT NULL,
  `standard_id` bigint(20) DEFAULT NULL,
  `subject_ids` bigint(20) DEFAULT NULL,
  `university_id` bigint(20) DEFAULT NULL,
  `degree_type_id` bigint(20) DEFAULT NULL,
  `exam_type_id` bigint(20) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_register`
--

INSERT INTO `tbl_register` (`id`, `institute_type_id`, `board_id`, `medium_id`, `class_category_id`, `standard_id`, `subject_ids`, `university_id`, `degree_type_id`, `exam_type_id`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 2, 1, 1, 3, 9, 1, NULL, NULL, NULL, 1, 0, '2024-11-26 15:42:18', '2024-11-26 15:42:18'),
(2, 3, NULL, NULL, NULL, NULL, NULL, 1, 2, NULL, 1, 0, '2024-11-26 15:43:03', '2024-11-26 15:43:03');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_standards`
--

CREATE TABLE `tbl_standards` (
  `id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_standards`
--

INSERT INTO `tbl_standards` (`id`, `category_id`, `name`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 1, 'LKG', 1, 0, '2024-11-26 15:07:25', '2024-11-26 15:07:25'),
(2, 1, 'HKG', 1, 0, '2024-11-26 15:07:25', '2024-11-26 15:07:25'),
(3, 2, '1th', 1, 0, '2024-11-26 15:08:12', '2024-11-26 15:08:12'),
(4, 2, '2th', 1, 0, '2024-11-26 15:08:12', '2024-11-26 15:08:12'),
(5, 2, '3th', 1, 0, '2024-11-26 15:08:12', '2024-11-26 15:08:12'),
(6, 3, '8th', 1, 0, '2024-11-26 15:08:32', '2024-11-26 15:08:32'),
(7, 3, '9th', 1, 0, '2024-11-26 15:08:32', '2024-11-26 15:08:32'),
(8, 4, '11th', 1, 0, '2024-11-26 15:08:53', '2024-11-26 15:08:53'),
(9, 4, '12th', 1, 0, '2024-11-26 15:08:53', '2024-11-26 15:08:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE `tbl_subjects` (
  `id` bigint(20) NOT NULL,
  `standard_id` bigint(20) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_subjects`
--

INSERT INTO `tbl_subjects` (`id`, `standard_id`, `name`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 1, 'Playing Game', 1, 0, '2024-11-26 15:10:09', '2024-11-26 15:10:09'),
(2, 4, 'Account', 1, 0, '2024-11-26 15:10:09', '2024-11-26 15:10:09'),
(3, 3, 'Gujrati', 1, 0, '2024-11-26 15:10:33', '2024-11-26 15:10:33'),
(4, 3, 'Hindi', 1, 0, '2024-11-26 15:10:33', '2024-11-26 15:10:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_universities`
--

CREATE TABLE `tbl_universities` (
  `id` bigint(1) NOT NULL,
  `name` varchar(128) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `insert_datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_universities`
--

INSERT INTO `tbl_universities` (`id`, `name`, `is_active`, `is_delete`, `insert_datetime`, `update_datetime`) VALUES
(1, 'GTU', 1, 0, '2024-11-26 15:11:03', '2024-11-26 15:11:03'),
(2, 'GU', 1, 0, '2024-11-26 15:11:03', '2024-11-26 15:11:03'),
(3, 'Saurashtra', 1, 0, '2024-11-26 15:11:03', '2024-11-26 15:11:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_boards`
--
ALTER TABLE `tbl_boards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_class_categories`
--
ALTER TABLE `tbl_class_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_competitive_exam_type`
--
ALTER TABLE `tbl_competitive_exam_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_degree_type`
--
ALTER TABLE `tbl_degree_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_institute_type`
--
ALTER TABLE `tbl_institute_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_medium`
--
ALTER TABLE `tbl_medium`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_register`
--
ALTER TABLE `tbl_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_standards`
--
ALTER TABLE `tbl_standards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_universities`
--
ALTER TABLE `tbl_universities`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_boards`
--
ALTER TABLE `tbl_boards`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_class_categories`
--
ALTER TABLE `tbl_class_categories`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_competitive_exam_type`
--
ALTER TABLE `tbl_competitive_exam_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_degree_type`
--
ALTER TABLE `tbl_degree_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_institute_type`
--
ALTER TABLE `tbl_institute_type`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_medium`
--
ALTER TABLE `tbl_medium`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_register`
--
ALTER TABLE `tbl_register`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_standards`
--
ALTER TABLE `tbl_standards`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_universities`
--
ALTER TABLE `tbl_universities`
  MODIFY `id` bigint(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
