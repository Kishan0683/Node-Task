const express = require('express');
const router = express.Router();

const users = require('../controller/user'); // Controller
const { validateInstitute, validateStandardSelection, validateSubjectSelection } = require('../validation/user'); // Validation

router.get('/institute-types', users.getInstituteTypes);
router.post('/get-boards', users.getBoards);
router.post('/get-mediums', users.getMediums);
router.post('/get-class-categories', users.getClassCategories);
router.post('/get-standards', validateStandardSelection, users.getStandards);
router.post('/get-subjects', validateSubjectSelection, users.getSubjects);
router.post('/register', validateInstitute, users.registerInstitute);

module.exports = router;
