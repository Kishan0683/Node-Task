const Joi = require('joi');

// Validate standard selection
const standardSelectionSchema = Joi.object({
  category_id: Joi.number().integer().required(),
});

// Validate subject selection
const subjectSelectionSchema = Joi.object({
  standard_id: Joi.number().integer().required(),
});

// Validate institute registration
const instituteRegistrationSchema = Joi.object({
  institute_type_id: Joi.number().integer().required(),
  board_id: Joi.number().integer().allow(null),
  medium_id: Joi.number().integer().allow(null),
  class_category_id: Joi.number().integer().allow(null),
  standard_id: Joi.number().integer().allow(null),
  subject_ids: Joi.string().allow(null),
  university_id: Joi.number().integer().allow(null),
  degree_type_id: Joi.number().integer().allow(null),
  exam_type_id: Joi.number().integer().allow(null),
});

// Middleware for validation
const validateStandardSelection = (req, res, next) => {
  const { error } = standardSelectionSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ success: false, message: 'Validation error', details: error.details });
  }
  next();
};

const validateSubjectSelection = (req, res, next) => {
  const { error } = subjectSelectionSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ success: false, message: 'Validation error', details: error.details });
  }
  next();
};

const validateInstitute = (req, res, next) => {
  const { error } = instituteRegistrationSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ success: false, message: 'Validation error', details: error.details });
  }
  next();
};

module.exports = { validateStandardSelection, validateSubjectSelection, validateInstitute };
